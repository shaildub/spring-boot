package com.cap.Hibernate;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Hiber {

	@Id
	private Integer hid;
	private String hname;
	private Integer hclass;
	
	public Integer getHid() {
		return hid;
	}
	public void setHid(Integer hid) {
		this.hid = hid;
	}
	public String getHname() {
		return hname;
	}
	public void setHname(String hname) {
		this.hname = hname;
	}
	public Integer getHclass() {
		return hclass;
	}
	public void setHclass(Integer hclass) {
		this.hclass = hclass;
	}
	
}
