package com.capgemini.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("com.capgemini")
@SpringBootApplication
public class SpringBootJpAwithRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpAwithRestApplication.class, args);
	}
}
