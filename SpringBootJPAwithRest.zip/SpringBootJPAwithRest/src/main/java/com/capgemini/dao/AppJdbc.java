//package com.capgemini.dao;
//
//import javax.sql.DataSource;
//
//public class AppJdbc implements AppDao {
//
//	private DataSource dataSource; 
//	private JdbcTemplate jdbcTemplateObject;
//	 	
//	@Override
//	public void setDataSource(DataSource ds) {
//		 this.dataSource=ds;
//		 this.jdbcTemplateObject=new JdbcTemplate(dataSource);
//	}
//
//	@Override
//	public void insert(String username, String password, Long mobileno) {
//		 String sql="insert into App(username, password, mobileno) values(?,?,?)";
//		 jdbcTemplateObject.update(sql,username, password, mobileno);
//		 System.out.println( "\n---Record  " + username + "  Inserted Successfully---\n" );
//	}
//
//}
