//package com.capgemini.dao;
//
//import javax.sql.DataSource;
//
//public interface AppDao {
//
//	public void setDataSource(DataSource ds);
//	public void insert(String username, String password, Long mobileno);
//
//}
