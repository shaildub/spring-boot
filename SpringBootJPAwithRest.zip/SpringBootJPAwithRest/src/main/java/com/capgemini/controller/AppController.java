package com.capgemini.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

//import com.capgemini.dao.AppJdbc;

@Controller
public class AppController {

	@RequestMapping("/")
	public String blank() {
		return "login";
	}	
	
	@RequestMapping("/welcome")
	public ModelAndView Welcome(HttpServletRequest requ, HttpServletResponse resp) {
		String name = requ.getParameter("luser");
		if(name!=null)
		{
//			if(name.equalsIgnoreCase("shaily"))
//				out.println("Valid User");
//			else
//				out.println("Invalid credentials provided!!");
		}
		return new ModelAndView("welcome", "wmsg", name);
	}

	@RequestMapping("/register")
	public ModelAndView Register(HttpServletRequest requ, HttpServletResponse resp) {
		
//		ApplicationContext context=new ClassPathXmlApplicationContext("springmvc-servlet.xml");
//		AppJdbc obj= (AppJdbc)context.getBean("jdbctemp");
//		
//		String name = requ.getParameter("ruser");
//		String pass = requ.getParameter("rpass");
//		Long mono = requ.getParameter("rmono");
//		obj.insert(name, pass, mno);
		
		String name = requ.getParameter("luser");
		return new ModelAndView("register", "rmsg", name);
	}
	
	@RequestMapping("/login")
	public ModelAndView Login(HttpServletRequest requ, HttpServletResponse resp) {
		String name = requ.getParameter("ruser");
		return new ModelAndView("login", "lmsg", name);
	}

}
